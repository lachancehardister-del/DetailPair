"""PKINet-v2 PKSModule minimal PyTorch port, fixed a33aa22d188c9946cc83fba60e3bb8ac0ec82ff7.
Apache-2.0; see sources/LICENSE_pkinet.txt and NOTICE_SOURCES.md.
Only build_norm_layer(BN) is replaced by equivalent BatchNorm2d. Not a full PKINet reproduction.
"""
import torch
from torch import nn

def build_norm_layer(cfg,channels):
    if cfg!={'type':'BN'}:raise ValueError('Only audited default BN configuration supported')
    return 'BN',nn.BatchNorm2d(channels)

def _fuse_bn_tensor(conv, bn):
    """Fuses BN tensor into Conv tensor."""
    if conv is None: 
        kernel = torch.zeros(bn.num_features, 1, 1, 1, device=bn.weight.device)
    else:
        kernel = conv.weight
    running_mean, running_var = bn.running_mean, bn.running_var
    gamma, beta, eps = bn.weight, bn.bias, bn.eps
    std = (running_var + eps).sqrt()
    t = (gamma / std).reshape(-1, 1, 1, 1)
    if conv is None:
        kernel = torch.ones(bn.num_features, 1, 1, 1, device=bn.weight.device)
        return kernel * t, beta - running_mean * gamma / std
    return kernel * t, beta - running_mean * gamma / std

class PKSModule(nn.Module):
    """
    [PKINet-v2] Poly-Kernel Scope (PKS) Module
    Branches:
    1. Axial Dense: 1x19 + 19x1 (Series) -> RF 19 [Global Backbone]
    2. Sparse: 7x7, d=3 -> RF 19 [Wide Context]
    3. Sparse: 5x5, d=3 -> RF 13 [Medium Transition]
    4. Sparse: 3x3, d=3 -> RF 7  [New: Sub-Medium]
    5. Dense:  3x3, d=1 -> RF 3  [Micro Texture]
    """
    def __init__(self, dim, deploy=False, auto_reparam=False,
                 norm_cfg=dict(type='BN'), branch_scale=1.0):
        super().__init__()
        self.deploy = deploy
        self.auto_reparam = auto_reparam
        self.dim = dim
        self.branch_scale = branch_scale
        
        # Max Kernel Size for Fusion (Determined by RF of Branch 1 & 2)
        # Branch 1: 19x19
        # Branch 2: 7 + (7-1)*(3-1) = 7 + 12 = 19
        self.max_k = 19 

        # [Head] Pre-process Conv (5x5) - Kept from V5 structure
        self.conv0 = nn.Conv2d(dim, dim, 5, padding=2, groups=dim)
        
        # [Tail] 1x1 Mixing
        self.conv1 = nn.Conv2d(dim, dim, 1)

        if deploy:
            # Deployment: Single Fused Large Kernel (19x19)
            self.fused_parallel_conv = nn.Conv2d(dim, dim, kernel_size=self.max_k, 
                                                 padding=self.max_k//2, 
                                                 groups=dim, bias=True)
        else:
            # --- Branch 1: Axial Dense (1x19 + 19x1) ---
            k_axial = 19
            self.branch1_axial = nn.Sequential(
                nn.Conv2d(dim, dim, (1, k_axial), stride=1, padding=(0, k_axial//2), groups=dim, bias=False),
                nn.Conv2d(dim, dim, (k_axial, 1), stride=1, padding=(k_axial//2, 0), groups=dim, bias=False),
                build_norm_layer(norm_cfg, dim)[1]
            )

            # --- Branch 2: Sparse (7x7, d=3) ---
            k_b2, d_b2 = 7, 3
            pad_b2 = (k_b2 - 1) * d_b2 // 2
            self.branch2_sparse = nn.Sequential(
                nn.Conv2d(dim, dim, k_b2, stride=1, padding=pad_b2, dilation=d_b2, groups=dim, bias=False),
                build_norm_layer(norm_cfg, dim)[1]
            )

            # --- Branch 3: Sparse (5x5, d=3) ---
            k_b3, d_b3 = 5, 3
            pad_b3 = (k_b3 - 1) * d_b3 // 2
            self.branch3_sparse = nn.Sequential(
                nn.Conv2d(dim, dim, k_b3, stride=1, padding=pad_b3, dilation=d_b3, groups=dim, bias=False),
                build_norm_layer(norm_cfg, dim)[1]
            )

            # --- Branch 4: Sparse (3x3, d=3) [NEW] ---
            k_b4, d_b4 = 3, 3
            pad_b4 = (k_b4 - 1) * d_b4 // 2
            self.branch4_sparse = nn.Sequential(
                nn.Conv2d(dim, dim, k_b4, stride=1, padding=pad_b4, dilation=d_b4, groups=dim, bias=False),
                build_norm_layer(norm_cfg, dim)[1]
            )

            # --- Branch 5: Dense (3x3, d=1) ---
            self.branch5_dense = nn.Sequential(
                nn.Conv2d(dim, dim, 3, padding=1, groups=dim, bias=False),
                build_norm_layer(norm_cfg, dim)[1]
            )

    def forward(self, x):
        if self.auto_reparam and not self.training and not self.deploy:
            self.switch_to_deploy()

        if self.deploy:
            attn = self.conv0(x)
            attn = self.fused_parallel_conv(attn)
            attn = self.conv1(attn)
            return x * attn
        
        # Training Mode
        x_feat = self.conv0(x)
        
        # Accumulate all 5 branches
        # 1. Axial 19x19
        attn = self.branch1_axial(x_feat)
        # 2. Sparse 7x7 (d=3)
        attn = attn + self.branch2_sparse(x_feat)
        # 3. Sparse 5x5 (d=3)
        attn = attn + self.branch3_sparse(x_feat)
        # 4. Sparse 3x3 (d=3)
        attn = attn + self.branch4_sparse(x_feat)
        # 5. Dense 3x3
        attn = attn + self.branch5_dense(x_feat)
        attn = attn * self.branch_scale
        
        # Tail Proj
        attn = self.conv1(attn)
            
        return x * attn

    def switch_to_deploy(self):
        if self.deploy: return
        
        device = self.branch1_axial[0].weight.device
        
        # Initialize the master fused kernel (19x19)
        fused_kernel = torch.zeros(self.dim, 1, self.max_k, self.max_k, device=device)
        fused_bias = torch.zeros(self.dim, device=device)
        
        center_k = self.max_k // 2  # Center index of 19x19 (i.e., 9)

        # === Helper for Dilated Fusion ===
        def fuse_dilated_branch(branch, k_size, dilation):
            # Fuse Conv+BN
            k_w, b_w = _fuse_bn_tensor(branch[0], branch[1]) # (D, 1, k, k)
            
            center_small = k_size // 2
            
            # Scatter weights into the large fused_kernel
            for i in range(k_size):
                for j in range(k_size):
                    # Calculate position in large kernel
                    offset_h = (i - center_small) * dilation
                    offset_w = (j - center_small) * dilation
                    
                    h_idx = center_k + offset_h
                    w_idx = center_k + offset_w
                    
                    # Safe check (though design guarantees fit)
                    if 0 <= h_idx < self.max_k and 0 <= w_idx < self.max_k:
                        fused_kernel[:, :, h_idx, w_idx] += k_w[:, :, i, j]
            
            return b_w

        # 1. Fuse Branch 1 (Axial Series: 1x19 * 19x1)
        k1 = self.branch1_axial[0].weight # 1x19
        k2, b2 = _fuse_bn_tensor(self.branch1_axial[1], self.branch1_axial[2]) # 19x1 fused with BN
        
        # Matrix Mul: (D, 1, 19, 1) @ (D, 1, 1, 19) -> (D, 1, 19, 19)
        k_axial_eff = torch.matmul(k2, k1)
        
        # Branch 1 is exactly 19x19, so direct addition
        fused_kernel += k_axial_eff
        fused_bias += b2

        # 2. Fuse Branch 2 (7x7, d=3)
        fused_bias += fuse_dilated_branch(self.branch2_sparse, k_size=7, dilation=3)

        # 3. Fuse Branch 3 (5x5, d=3)
        fused_bias += fuse_dilated_branch(self.branch3_sparse, k_size=5, dilation=3)

        # 4. Fuse Branch 4 (3x3, d=3)
        fused_bias += fuse_dilated_branch(self.branch4_sparse, k_size=3, dilation=3)

        # 5. Fuse Branch 5 (3x3, d=1)
        fused_bias += fuse_dilated_branch(self.branch5_dense, k_size=3, dilation=1)
        fused_kernel *= self.branch_scale
        fused_bias *= self.branch_scale

        # Finalize
        self.fused_parallel_conv = nn.Conv2d(self.dim, self.dim, self.max_k, 
                                             padding=self.max_k//2, 
                                             groups=self.dim, bias=True)
        self.fused_parallel_conv.weight.data = fused_kernel
        self.fused_parallel_conv.bias.data = fused_bias
        
        # Cleanup
        del self.branch1_axial, self.branch2_sparse, self.branch3_sparse, self.branch4_sparse, self.branch5_dense
        self.deploy = True
