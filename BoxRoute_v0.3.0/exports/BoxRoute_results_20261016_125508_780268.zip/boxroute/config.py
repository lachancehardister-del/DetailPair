"""Frozen research protocol and explicit real-GPU versus synthetic CPU preflight."""
import hashlib,importlib,inspect,platform,subprocess,sys
from pathlib import Path
import yaml
from .identity import dump,file_sha256
ROOT=Path(__file__).resolve().parents[1]


def load_protocol():
    data=yaml.safe_load((ROOT/'protocol.yaml').read_text(encoding='utf-8-sig'))
    if data['version']!='BoxRoute-v0.3.0-proposed-1.0':raise ValueError('Unknown frozen protocol')
    # The source manifest is checked independently; edits to the frozen protocol are rejected.
    import json
    manifest=json.loads((ROOT/'sources_manifest.json').read_text())
    if file_sha256(ROOT/'protocol.yaml')!=manifest['protocol_sha256']:raise ValueError('Frozen protocol modified')
    return data


def preflight(out,synthetic=False):
    import torch,torchvision,ultralytics
    from ultralytics import settings
    versions=dict(torch=torch.__version__,torchvision=torchvision.__version__,ultralytics=ultralytics.__version__)
    dump(Path(out)/'environment.json',dict(versions=versions,python=sys.version,platform=platform.platform(),cuda=torch.version.cuda,
        cuda_available=torch.cuda.is_available(),synthetic_check=synthetic))
    required={'torch':'2.5.1','torchvision':'0.20.1','ultralytics':'8.3.221'}
    if any(versions[k].split('+')[0]!=v for k,v in required.items()):raise RuntimeError('Pinned dependencies required; no installation or upgrades')
    if not synthetic:
        if versions['torch']!='2.5.1+cu121' or versions['torchvision']!='0.20.1+cu121' or torch.version.cuda!='12.1' or not torch.cuda.is_available():raise RuntimeError('Real G0/G1 requires the existing CUDA12.1 GPU0 stack; no CPU fallback')
        result=subprocess.run(['nvidia-smi'],capture_output=True,text=True,timeout=15)
        dump(Path(out)/'nvidia_smi.json',dict(exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr,gpu_name=torch.cuda.get_device_name(0)))
        if result.returncode:raise RuntimeError('GPU driver query failed')
    settings.update({k:False for k in ['sync','clearml','comet','dvc','hub','mlflow','neptune','raytune','wandb']})
    torch.set_num_threads(2);torch.use_deterministic_algorithms(True);torch.backends.cudnn.benchmark=False
    torch.backends.cudnn.deterministic=True;torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    source_modules=['ultralytics.nn.tasks','ultralytics.utils.loss','ultralytics.utils.tal','ultralytics.engine.trainer','ultralytics.models.yolo.detect.train','ultralytics.data.build','ultralytics.models.yolo.detect.val']
    identities={name:dict(path=str(Path(importlib.import_module(name).__file__)),sha256=file_sha256(importlib.import_module(name).__file__)) for name in source_modules}
    dump(Path(out)/'installed_source_identities.json',identities)
    return torch.device('cpu' if synthetic else 'cuda:0')
